const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const config = require('../config');

fs.mkdirSync(path.dirname(config.DB_PATH), { recursive: true });

const db = new DatabaseSync(config.DB_PATH);

// WAL mode: pembaca (getExams, getQuestions, dashboard admin) tidak saling
// blokir dengan penulis (submit, violation, heartbeat). Ini yang membuat
// backend ini jauh lebih tangguh untuk 500-700 siswa dibanding GAS+Sheets,
// yang menulis dengan LockService global (satu proses tulis pada satu waktu).
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA busy_timeout = 5000;');

/**
 * Skema tabel setara schema{} di setupDatabase() (Code.gs), lihat juga
 * PRD_Migrasi_Backend_Lokal_UjianGAS.md bagian 5 (Pemetaan Skema Data).
 */
function setupDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS admin (
      AdminID TEXT PRIMARY KEY,
      Nama TEXT NOT NULL,
      Email TEXT NOT NULL UNIQUE,
      PasswordHash TEXT NOT NULL,
      Salt TEXT,
      Role TEXT NOT NULL DEFAULT 'ADMIN',
      Status TEXT NOT NULL DEFAULT 'ACTIVE',
      CreatedAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS siswa (
      StudentID TEXT PRIMARY KEY,
      Nama TEXT NOT NULL,
      Email TEXT NOT NULL UNIQUE,
      PasswordHash TEXT NOT NULL,
      Salt TEXT,
      Kelas TEXT,
      Status TEXT NOT NULL DEFAULT 'ACTIVE',
      CreatedAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ujian (
      ExamID TEXT PRIMARY KEY,
      NamaUjian TEXT NOT NULL,
      Mapel TEXT,
      DurasiMenit INTEGER NOT NULL DEFAULT 0,
      Tanggal TEXT,
      JamMulai TEXT,
      JamSelesai TEXT,
      Status TEXT NOT NULL DEFAULT 'DRAFT',
      CreatedAt TEXT NOT NULL,
      CreatedBy TEXT,
      AntiCheatOn INTEGER NOT NULL DEFAULT 0,
      ExamLockOn INTEGER NOT NULL DEFAULT 0,
      PreventScreenshot INTEGER NOT NULL DEFAULT 0,
      PreventScreenRecording INTEGER NOT NULL DEFAULT 0,
      PreventCopyPaste INTEGER NOT NULL DEFAULT 0,
      DetectBackground INTEGER NOT NULL DEFAULT 0,
      DetectSplitScreen INTEGER NOT NULL DEFAULT 0,
      MaxViolations INTEGER NOT NULL DEFAULT 3,
      ActionAfterLimit TEXT NOT NULL DEFAULT 'LOCK',
      RequireSupervisorPin INTEGER NOT NULL DEFAULT 0,
      SupervisorPinHash TEXT,
      SupervisorPinSalt TEXT
    );

    CREATE TABLE IF NOT EXISTS soal (
      QuestionID TEXT PRIMARY KEY,
      ExamID TEXT NOT NULL REFERENCES ujian(ExamID),
      Pertanyaan TEXT NOT NULL,
      PilihanA TEXT,
      PilihanB TEXT,
      PilihanC TEXT,
      PilihanD TEXT,
      JawabanBenar TEXT,
      Bobot REAL NOT NULL DEFAULT 1,
      CreatedAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS undangan (
      InviteID TEXT PRIMARY KEY,
      ExamID TEXT NOT NULL REFERENCES ujian(ExamID),
      StudentID TEXT NOT NULL REFERENCES siswa(StudentID),
      Status TEXT NOT NULL DEFAULT 'PENDING',
      SentAt TEXT,
      MulaiPada TEXT
    );

    CREATE TABLE IF NOT EXISTS jawaban (
      AnswerID TEXT PRIMARY KEY,
      ExamID TEXT NOT NULL,
      StudentID TEXT NOT NULL,
      QuestionID TEXT NOT NULL,
      Jawaban TEXT,
      Waktu TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS nilai (
      ResultID TEXT PRIMARY KEY,
      ExamID TEXT NOT NULL,
      StudentID TEXT NOT NULL,
      Benar INTEGER NOT NULL DEFAULT 0,
      Salah INTEGER NOT NULL DEFAULT 0,
      Nilai REAL NOT NULL DEFAULT 0,
      Status TEXT NOT NULL DEFAULT 'SELESAI',
      Waktu TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS pengingat (
      ReminderID TEXT PRIMARY KEY,
      ExamID TEXT,
      Pesan TEXT,
      Target TEXT,
      Waktu TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS exam_sessions (
      SessionID TEXT PRIMARY KEY,
      ExamID TEXT NOT NULL,
      StudentID TEXT NOT NULL,
      InviteID TEXT,
      StartTime TEXT NOT NULL,
      ExpectedEndTime TEXT,
      ActualEndTime TEXT,
      Status TEXT NOT NULL DEFAULT 'ACTIVE',
      ViolationCount INTEGER NOT NULL DEFAULT 0,
      LastHeartbeat TEXT,
      DeviceInfo TEXT,
      AppVersion TEXT,
      CreatedAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS violations (
      ViolationID TEXT PRIMARY KEY,
      StudentID TEXT NOT NULL,
      ExamID TEXT NOT NULL,
      SessionID TEXT,
      Type TEXT,
      Severity TEXT,
      Timestamp TEXT NOT NULL,
      Description TEXT,
      Device TEXT,
      AppVersion TEXT,
      Status TEXT NOT NULL DEFAULT 'OPEN',
      CreatedAt TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      AuditID TEXT PRIMARY KEY,
      ActorID TEXT,
      ActorRole TEXT,
      Action TEXT,
      TargetID TEXT,
      ExamID TEXT,
      Timestamp TEXT NOT NULL,
      Description TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_soal_exam ON soal(ExamID);
    CREATE INDEX IF NOT EXISTS idx_undangan_exam_student ON undangan(ExamID, StudentID);
    CREATE INDEX IF NOT EXISTS idx_jawaban_exam_student ON jawaban(ExamID, StudentID);
    CREATE INDEX IF NOT EXISTS idx_nilai_exam_student ON nilai(ExamID, StudentID);
    CREATE INDEX IF NOT EXISTS idx_sessions_exam_student ON exam_sessions(ExamID, StudentID);
    CREATE INDEX IF NOT EXISTS idx_violations_student_exam ON violations(StudentID, ExamID);
  `);
}

module.exports = { db, setupDatabase };
