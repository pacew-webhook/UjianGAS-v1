const { db } = require('../db');

/**
 * Ambil semua baris tabel sebagai array of object, setara rows_(sheetName)
 * di Code.gs. Dipakai untuk operasi yang butuh filter/scan sederhana
 * (jumlah tabel di project ini kecil, jadi full-scan aman untuk skala
 * ratusan-ribuan baris; untuk query yang sering dipanggil di jalur kritis
 * -- lihat repo/*.js lain yang pakai query SQL langsung dengan index).
 */
function allRows(table) {
  return db.prepare(`SELECT * FROM ${table}`).all();
}

function findOne(table, whereSql, params) {
  return db.prepare(`SELECT * FROM ${table} WHERE ${whereSql} LIMIT 1`).get(...params) || null;
}

function findMany(table, whereSql, params) {
  return db.prepare(`SELECT * FROM ${table} WHERE ${whereSql}`).all(...params);
}

function insertRow(table, row) {
  const columns = Object.keys(row);
  const placeholders = columns.map(() => '?').join(', ');
  const values = columns.map((c) => row[c]);
  db.prepare(`INSERT INTO ${table} (${columns.join(', ')}) VALUES (${placeholders})`).run(...values);
  return row;
}

function updateById(table, idField, idValue, patch) {
  const columns = Object.keys(patch);
  if (columns.length === 0) return;
  const setSql = columns.map((c) => `${c} = ?`).join(', ');
  const values = columns.map((c) => patch[c]);
  db.prepare(`UPDATE ${table} SET ${setSql} WHERE ${idField} = ?`).run(...values, idValue);
}

/**
 * node:sqlite (DatabaseSync bawaan Node.js) belum punya helper
 * `.transaction()` seperti better-sqlite3, jadi dibuat manual dengan
 * BEGIN IMMEDIATE (lock tulis diambil di awal, bukan saat statement
 * tulis pertama -- mencegah race condition antar siswa yang submit
 * hampir bersamaan) ... COMMIT/ROLLBACK.
 */
function withTransaction(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

module.exports = { db, allRows, findOne, findMany, insertRow, updateById, withTransaction };
