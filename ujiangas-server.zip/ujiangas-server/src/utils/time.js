function safeNumber(v, fallback) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

/**
 * Port dari parseExamDateTime_(tanggal, jam) di Code.gs.
 * tanggal: 'YYYY-MM-DD', jam: 'HH:MM'
 */
function parseExamDateTime(tanggal, jam) {
  const dateParts = String(tanggal || '').trim().split('-');
  const timeParts = String(jam || '').trim().split(':');

  if (dateParts.length < 3 || timeParts.length < 2) return null;

  const year = parseInt(dateParts[0], 10);
  const month = parseInt(dateParts[1], 10);
  const day = parseInt(dateParts[2], 10);
  const hour = parseInt(timeParts[0], 10);
  const minute = parseInt(timeParts[1], 10);

  if ([year, month, day, hour, minute].some((n) => Number.isNaN(n))) {
    return null;
  }

  return new Date(year, month - 1, day, hour, minute, 0);
}

/**
 * Port dari getExamWindow_(exam) di Code.gs, termasuk penanganan
 * ujian yang melewati tengah malam (JamSelesai < JamMulai).
 */
function getExamWindow(exam) {
  const start = parseExamDateTime(exam.Tanggal, exam.JamMulai);
  let end = parseExamDateTime(exam.Tanggal, exam.JamSelesai);

  if (!start || !end) return null;

  if (end.getTime() <= start.getTime()) {
    end = new Date(end.getTime() + 24 * 60 * 60 * 1000);
  }

  return { start, end };
}

/**
 * Port dari isExamWithinWindow_(exam, allowGraceSeconds) di Code.gs.
 * Data Tanggal/Jam tidak lengkap -> jangan blokir (exam lama yang belum rapi).
 */
function isExamWithinWindow(exam, allowGraceSeconds, now = new Date()) {
  const window = getExamWindow(exam);
  if (!window) return true;

  const grace = safeNumber(allowGraceSeconds, 0) * 1000;
  const t = now.getTime();

  return t >= window.start.getTime() && t <= window.end.getTime() + grace;
}

/**
 * Port dari computePersonalDeadline_(startedAt, exam) di Code.gs.
 */
function computePersonalDeadline(startedAt, exam) {
  const durationMinutes = safeNumber(exam.DurasiMenit, 0);
  const byDuration = new Date(startedAt.getTime() + durationMinutes * 60000);

  const window = getExamWindow(exam);
  if (window && window.end.getTime() < byDuration.getTime()) {
    return window.end;
  }

  return byDuration;
}

module.exports = {
  safeNumber,
  parseExamDateTime,
  getExamWindow,
  isExamWithinWindow,
  computePersonalDeadline
};
