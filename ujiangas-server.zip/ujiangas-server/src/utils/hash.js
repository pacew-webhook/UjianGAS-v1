const crypto = require('crypto');

/**
 * Setara hash_() di Code.gs: SHA-256 -> hex lowercase.
 */
function sha256Hex(value) {
  return crypto.createHash('sha256').update(String(value ?? ''), 'utf8').digest('hex');
}

/**
 * Setara generateSalt_() di Code.gs (dua UUID digabung tanpa dash).
 */
function generateSalt() {
  return crypto.randomUUID().replace(/-/g, '') + crypto.randomUUID().replace(/-/g, '');
}

/**
 * Setara hashPassword_(password, salt) di Code.gs.
 */
function hashPassword(password, salt) {
  return sha256Hex(`${salt || ''}:${password || ''}`);
}

/**
 * Setara verifyPassword_(account, password) di Code.gs.
 * account: { PasswordHash, Salt }
 * Mendukung akun lama tanpa salt (fallback ke skema lama) supaya
 * proses migrasi dari data Sheets tidak memaksa reset password semua orang.
 */
function verifyPassword(account, password) {
  const salt = String(account.Salt || '');

  if (salt) {
    return String(account.PasswordHash || '') === hashPassword(password, salt);
  }

  return String(account.PasswordHash || '') === sha256Hex(password || '');
}

/**
 * Generate ID pendek dengan prefix, setara id_(prefix) di Code.gs.
 * Contoh: id('STU') -> 'STU-8F3A1B9C2D'
 */
function id(prefix) {
  const raw = crypto.randomUUID().replace(/-/g, '').slice(0, 10).toUpperCase();
  return `${prefix}-${raw}`;
}

module.exports = { sha256Hex, generateSalt, hashPassword, verifyPassword, id };
