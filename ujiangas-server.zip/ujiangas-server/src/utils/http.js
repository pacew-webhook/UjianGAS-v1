const querystring = require('querystring');

const MAX_BODY_BYTES = 5 * 1024 * 1024; // 5 MB, cukup longgar untuk payload jawaban ujian.

/**
 * Baca body request dan urai sebagai form-urlencoded ATAU JSON, tergantung
 * Content-Type. GasApi.kt (Android) saat ini mengirim FormBody
 * (application/x-www-form-urlencoded), jadi itu yang diprioritaskan agar
 * perubahan di Android minimal -- cukup ganti base URL.
 */
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];

    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new Error('Payload terlalu besar.'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });

    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      const contentType = String(req.headers['content-type'] || '');

      try {
        if (contentType.includes('application/json')) {
          resolve(raw ? JSON.parse(raw) : {});
        } else {
          // Default: application/x-www-form-urlencoded (sesuai GasApi.kt).
          resolve(querystring.parse(raw));
        }
      } catch (err) {
        reject(err);
      }
    });

    req.on('error', reject);
  });
}

function sendJson(res, statusCode, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

module.exports = { readBody, sendJson };
