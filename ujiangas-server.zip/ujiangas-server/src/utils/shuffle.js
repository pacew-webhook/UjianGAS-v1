/**
 * Port persis dari stringToSeed_() di Code.gs.
 * PENTING: hasil harus identik dengan versi GAS supaya urutan soal siswa
 * yang sudah mulai ujian di backend lama tidak berubah kalau migrasi
 * dilakukan di tengah periode ujian.
 */
function stringToSeed(str) {
  let h = 0;
  const s = String(str);

  for (let i = 0; i < s.length; i++) {
    h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  }

  return h >>> 0;
}

/**
 * Port persis dari mulberry32_() di Code.gs.
 */
function mulberry32(seed) {
  let a = seed >>> 0;

  return function () {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Port persis dari seededShuffle_() di Code.gs.
 * Seed yang dipakai pemanggil: `${studentId}:${examId}` (lihat services/exams.js),
 * sama seperti StudentID:ExamID di Code.gs asli.
 */
function seededShuffle(array, seedString) {
  const arr = array.slice();
  const rand = mulberry32(stringToSeed(seedString));

  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }

  return arr;
}

module.exports = { stringToSeed, mulberry32, seededShuffle };
