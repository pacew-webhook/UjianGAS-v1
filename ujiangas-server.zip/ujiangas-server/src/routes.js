const { loginStudentApi, registerStudentApi } = require('./services/auth');
const { getStudentExamsApi, getStudentQuestionsApi, submitStudentExamApi } = require('./services/exams');
const { getStudentInvitationsApi, getStudentResultsApi, getStudentRemindersApi } = require('./services/misc');
const {
  reportViolationApi,
  reportViolationBatchApi,
  heartbeatApi,
  getSessionStatusApi,
  unlockSessionWithPinApi
} = require('./services/anticheat');

/**
 * Setara switch(action) di doPost(e) pada Code.gs. Nama action dan bentuk
 * parameter sengaja dibuat identik supaya GasApi.kt (Android) cukup ganti
 * base URL, tanpa perlu mengubah nama field.
 */
const handlers = {
  login: loginStudentApi,
  register: registerStudentApi,
  exams: getStudentExamsApi,
  questions: getStudentQuestionsApi,
  submit: submitStudentExamApi,
  invitations: getStudentInvitationsApi,
  results: getStudentResultsApi,
  reminders: getStudentRemindersApi,
  violation: reportViolationApi,
  violation_batch: reportViolationBatchApi,
  heartbeat: heartbeatApi,
  unlock: unlockSessionWithPinApi,
  session_status: getSessionStatusApi
};

function dispatch(data) {
  const action = String(data.action || '').trim();
  const handler = handlers[action];

  if (!handler) {
    return { ok: false, message: `Action tidak dikenal: ${action}` };
  }

  try {
    return handler(data);
  } catch (err) {
    return { ok: false, message: err && err.message ? err.message : String(err) };
  }
}

module.exports = { dispatch, handlers };
