const { findOne, insertRow, updateById } = require('../repo/repo');
const { generateSalt, hashPassword, verifyPassword, id } = require('../utils/hash');

/**
 * Setara migratePasswordIfNeeded_ di Code.gs: akun lama tanpa salt yang
 * berhasil login (via fallback SHA-256 polos) otomatis di-upgrade diam-diam.
 */
function migratePasswordIfNeeded(student, password) {
  if (student.Salt) return;
  try {
    const newSalt = generateSalt();
    updateById('siswa', 'StudentID', student.StudentID, {
      PasswordHash: hashPassword(password, newSalt),
      Salt: newSalt
    });
  } catch (_err) {
    // Migrasi gagal tidak boleh menggagalkan login yang sudah valid.
  }
}

/**
 * Setara loginStudentApi_(data) di Code.gs.
 * data: { email, password }
 */
function loginStudentApi(data) {
  const email = String(data.email || '').trim().toLowerCase();
  const password = String(data.password || '');

  if (!email || !password) {
    return { ok: false, message: 'Email dan password wajib diisi.' };
  }

  const student = findOne('siswa', 'LOWER(Email) = ?', [email]);

  if (!student || !verifyPassword(student, password)) {
    return { ok: false, message: 'Email atau password salah.' };
  }

  if (String(student.Status || '').toUpperCase() === 'NONAKTIF') {
    return { ok: false, message: 'Akun kamu dinonaktifkan. Hubungi admin.' };
  }

  migratePasswordIfNeeded(student, password);

  return {
    ok: true,
    data: {
      studentId: student.StudentID,
      nama: student.Nama,
      email: student.Email,
      kelas: student.Kelas
    }
  };
}

/**
 * Setara registerStudentApi_(data) di Code.gs.
 * data: { nama, email, password, kelas }
 */
function registerStudentApi(data) {
  const nama = String(data.nama || '').trim();
  const email = String(data.email || '').trim().toLowerCase();
  const password = String(data.password || '');
  const kelas = String(data.kelas || '').trim();

  if (!nama || !email || !password) {
    return { ok: false, message: 'Nama, email, dan password wajib diisi.' };
  }

  const existing = findOne('siswa', 'LOWER(Email) = ?', [email]);
  if (existing) {
    return { ok: false, message: 'Email sudah terdaftar.' };
  }

  const salt = generateSalt();
  const student = {
    StudentID: id('STU'),
    Nama: nama,
    Email: email,
    PasswordHash: hashPassword(password, salt),
    Salt: salt,
    Kelas: kelas,
    Status: 'ACTIVE',
    CreatedAt: new Date().toISOString()
  };

  insertRow('siswa', student);

  return {
    ok: true,
    data: { studentId: student.StudentID, nama: student.Nama, email: student.Email }
  };
}

module.exports = { loginStudentApi, registerStudentApi };
