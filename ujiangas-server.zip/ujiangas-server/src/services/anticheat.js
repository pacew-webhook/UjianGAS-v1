const { insertRow, updateById, withTransaction } = require('../repo/repo');
const { id, hashPassword } = require('../utils/hash');
const { safeNumber } = require('../utils/time');
const { findStudentByEmail, findExamById, findSession } = require('./exams');

/**
 * Setara nextStatusAfterViolation_(currentStatus, violationCount, exam)
 * di Code.gs — rules engine sederhana (bagian 19 PRD Anti-Cheat).
 */
function nextStatusAfterViolation(currentStatus, violationCount, exam) {
  const closed = ['SUBMITTED', 'FORCE_SUBMITTED', 'TERMINATED', 'EXPIRED'];
  if (closed.includes(String(currentStatus || '').toUpperCase())) {
    return String(currentStatus).toUpperCase();
  }

  const max = safeNumber(exam.MaxViolations, 3) || 3;

  if (violationCount >= max) {
    const action = String(exam.ActionAfterLimit || 'LOCK').toUpperCase();
    return action === 'TERMINATE' ? 'TERMINATED' : 'LOCKED';
  }

  if (violationCount > 0) return 'WARNING';
  return 'ACTIVE';
}

function auditLog(actorId, actorRole, action, targetId, examId, description) {
  try {
    insertRow('audit_logs', {
      AuditID: id('A'),
      ActorID: actorId || '',
      ActorRole: actorRole || '',
      Action: action || '',
      TargetID: targetId || '',
      ExamID: examId || '',
      Timestamp: new Date().toISOString(),
      Description: description || ''
    });
  } catch (_err) {
    // Audit log tidak boleh menggagalkan aksi utama.
  }
}

/**
 * Setara reportViolationApi_(data) di Code.gs.
 */
function reportViolationApi(data) {
  const email = String(data.email || '').trim().toLowerCase();
  const examId = String(data.examId || '').trim();
  const sessionId = String(data.sessionId || '').trim();
  const type = String(data.type || '').trim().toUpperCase();
  const severity = String(data.severity || 'WARNING').trim().toUpperCase();
  const description = String(data.description || '').trim();
  const device = String(data.device || '').trim();
  const appVersion = String(data.appVersion || '').trim();

  const student = findStudentByEmail(email);
  if (!student) return { ok: false, message: 'Siswa tidak ditemukan.' };
  if (!examId || !sessionId || !type) {
    return { ok: false, message: 'examId, sessionId, dan type wajib diisi.' };
  }

  const exam = findExamById(examId);
  if (!exam) return { ok: false, message: 'Ujian tidak ditemukan.' };

  const session = findSession(sessionId);
  if (!session || String(session.StudentID) !== String(student.StudentID) || String(session.ExamID) !== examId) {
    return { ok: false, message: 'Sesi ujian tidak valid.' };
  }

  return withTransaction(() => {
    insertRow('violations', {
      ViolationID: id('V'),
      StudentID: student.StudentID,
      ExamID: examId,
      SessionID: sessionId,
      Type: type,
      Severity: severity,
      Timestamp: new Date().toISOString(),
      Description: description,
      Device: device,
      AppVersion: appVersion,
      Status: 'RECORDED',
      CreatedAt: new Date().toISOString()
    });

    const freshSession = findSession(sessionId);
    const newCount = safeNumber(freshSession.ViolationCount, 0) + 1;
    const newStatus = nextStatusAfterViolation(freshSession.Status, newCount, exam);

    updateById('exam_sessions', 'SessionID', sessionId, {
      ViolationCount: newCount,
      Status: newStatus,
      LastHeartbeat: new Date().toISOString()
    });

    return {
      ok: true,
      violationCount: newCount,
      maxViolations: safeNumber(exam.MaxViolations, 3) || 3,
      status: newStatus,
      requireSupervisorPin: !!exam.RequireSupervisorPin
    };
  });
}

/**
 * Setara reportViolationBatchApi_(data) di Code.gs — dipakai untuk
 * ViolationQueue offline Android saat koneksi kembali pulih.
 */
function reportViolationBatchApi(data) {
  let items = [];
  try {
    items = JSON.parse(String(data.items || '[]'));
  } catch (_err) {
    return { ok: false, message: 'Format batch tidak valid.' };
  }

  if (!Array.isArray(items) || !items.length) {
    return { ok: false, message: 'Tidak ada data pelanggaran pada batch ini.' };
  }

  let lastResult = null;
  let processed = 0;

  items.forEach((item) => {
    const result = reportViolationApi({
      email: data.email,
      examId: item.examId,
      sessionId: item.sessionId,
      type: item.type,
      severity: item.severity,
      description: item.description,
      device: item.device,
      appVersion: item.appVersion
    });
    if (result.ok) {
      processed++;
      lastResult = result;
    }
  });

  return Object.assign({ ok: processed > 0, processed, total: items.length }, lastResult || {});
}

/**
 * Setara heartbeatApi_(data) di Code.gs.
 */
function heartbeatApi(data) {
  const email = String(data.email || '').trim().toLowerCase();
  const examId = String(data.examId || '').trim();
  const sessionId = String(data.sessionId || '').trim();

  const student = findStudentByEmail(email);
  if (!student) return { ok: false, message: 'Siswa tidak ditemukan.' };

  const session = findSession(sessionId);
  if (!session || String(session.StudentID) !== String(student.StudentID) || String(session.ExamID) !== examId) {
    return { ok: false, message: 'Sesi ujian tidak valid.' };
  }

  updateById('exam_sessions', 'SessionID', sessionId, { LastHeartbeat: new Date().toISOString() });

  return { ok: true, status: session.Status, violationCount: safeNumber(session.ViolationCount, 0) };
}

/**
 * Setara getSessionStatusApi_(data) di Code.gs.
 */
function getSessionStatusApi(data) {
  const sessionId = String(data.sessionId || '').trim();
  const session = findSession(sessionId);
  if (!session) return { ok: false, message: 'Sesi ujian tidak ditemukan.' };
  return { ok: true, status: session.Status, violationCount: safeNumber(session.ViolationCount, 0) };
}

/**
 * Setara unlockSessionWithPinApi_(data) di Code.gs.
 */
function unlockSessionWithPinApi(data) {
  const email = String(data.email || '').trim().toLowerCase();
  const examId = String(data.examId || '').trim();
  const sessionId = String(data.sessionId || '').trim();
  const pin = String(data.pin || '').trim();

  const student = findStudentByEmail(email);
  if (!student) return { ok: false, message: 'Siswa tidak ditemukan.' };

  const exam = findExamById(examId);
  if (!exam) return { ok: false, message: 'Ujian tidak ditemukan.' };

  const session = findSession(sessionId);
  if (!session || String(session.StudentID) !== String(student.StudentID) || String(session.ExamID) !== examId) {
    return { ok: false, message: 'Sesi ujian tidak valid.' };
  }

  if (String(session.Status).toUpperCase() === 'TERMINATED') {
    return { ok: false, message: 'Ujian sudah dihentikan dan tidak dapat dibuka kembali.' };
  }

  if (String(session.Status).toUpperCase() !== 'LOCKED') {
    return { ok: true, status: session.Status, message: 'Sesi tidak dalam status terkunci.' };
  }

  const pinHash = String(exam.SupervisorPinHash || '');
  const pinSalt = String(exam.SupervisorPinSalt || '');

  if (!pinHash) {
    return { ok: false, message: 'PIN Pengawas belum diatur oleh Guru untuk ujian ini.' };
  }

  if (!pin || hashPassword(pin, pinSalt) !== pinHash) {
    auditLog(student.StudentID, 'STUDENT', 'UNLOCK_ATTEMPT_FAILED', session.SessionID, examId, 'PIN Pengawas salah.');
    return { ok: false, message: 'PIN Pengawas salah.' };
  }

  updateById('exam_sessions', 'SessionID', sessionId, { Status: 'ACTIVE' });
  auditLog(student.StudentID, 'SUPERVISOR', 'UNLOCK_STUDENT', session.SessionID, examId, 'Sesi dibuka kembali dengan PIN Pengawas.');

  return { ok: true, status: 'ACTIVE', message: 'Ujian dibuka kembali.' };
}

module.exports = {
  reportViolationApi,
  reportViolationBatchApi,
  heartbeatApi,
  getSessionStatusApi,
  unlockSessionWithPinApi
};
