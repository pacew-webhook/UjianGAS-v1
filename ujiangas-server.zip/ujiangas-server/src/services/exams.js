const { db, findOne, findMany, insertRow, updateById, withTransaction } = require('../repo/repo');
const { id } = require('../utils/hash');
const { seededShuffle } = require('../utils/shuffle');
const { isExamWithinWindow, computePersonalDeadline, safeNumber } = require('../utils/time');

function findStudentByEmail(email) {
  return findOne('siswa', 'LOWER(Email) = ?', [String(email || '').toLowerCase()]);
}

function findExamById(examId) {
  return findOne('ujian', 'ExamID = ?', [examId]);
}

function findInvitation(studentId, examId) {
  return findOne(
    'undangan',
    "StudentID = ? AND ExamID = ? AND UPPER(COALESCE(Status,'')) != 'CANCELLED'",
    [studentId, examId]
  );
}

function studentAlreadySubmitted(studentId, examId) {
  return !!findOne('nilai', 'StudentID = ? AND ExamID = ?', [studentId, examId]);
}

function findActiveSessionFor(studentId, examId) {
  const rows = db
    .prepare('SELECT * FROM exam_sessions WHERE StudentID = ? AND ExamID = ? ORDER BY rowid ASC')
    .all(studentId, examId);
  return rows.length ? rows[rows.length - 1] : null;
}

function findSession(sessionId) {
  return findOne('exam_sessions', 'SessionID = ?', [sessionId]);
}

/**
 * Setara examAntiCheatConfig_(exam) di Code.gs. Kolom disimpan sebagai
 * INTEGER 0/1 (lihat db.js), berbeda dari GAS yang menyimpan string 'ON'/'OFF' -
 * makna akhirnya sama.
 */
function examAntiCheatConfig(exam) {
  return {
    antiCheatOn: !!exam.AntiCheatOn,
    examLockOn: !!exam.ExamLockOn,
    preventScreenshot: !!exam.PreventScreenshot,
    preventScreenRecording: !!exam.PreventScreenRecording,
    preventCopyPaste: !!exam.PreventCopyPaste,
    detectBackground: !!exam.DetectBackground,
    detectSplitScreen: !!exam.DetectSplitScreen,
    maxViolations: safeNumber(exam.MaxViolations, 3) || 3,
    actionAfterLimit: String(exam.ActionAfterLimit || 'LOCK').toUpperCase() === 'TERMINATE' ? 'TERMINATE' : 'LOCK',
    requireSupervisorPin: !!exam.RequireSupervisorPin
  };
}

/**
 * Setara ensureExamSession_(student, exam, invitation, deadline) di Code.gs.
 */
function ensureExamSession(student, exam, invitation, deadline) {
  const existing = findActiveSessionFor(student.StudentID, exam.ExamID);
  const closed = ['SUBMITTED', 'FORCE_SUBMITTED', 'TERMINATED', 'EXPIRED'];

  if (existing && !closed.includes(String(existing.Status || '').toUpperCase())) {
    return existing;
  }

  const now = new Date().toISOString();
  const session = {
    SessionID: id('SES'),
    ExamID: exam.ExamID,
    StudentID: student.StudentID,
    InviteID: invitation.InviteID,
    StartTime: now,
    ExpectedEndTime: deadline.toISOString(),
    ActualEndTime: null,
    Status: 'ACTIVE',
    ViolationCount: 0,
    LastHeartbeat: now,
    DeviceInfo: '',
    AppVersion: '',
    CreatedAt: now
  };

  insertRow('exam_sessions', session);
  return session;
}

/**
 * Setara getStudentExamsApi_(data) di Code.gs.
 */
function getStudentExamsApi(data) {
  const email = String(data.email || '').trim().toLowerCase();
  const student = findStudentByEmail(email);
  if (!student) return { ok: false, message: 'Siswa tidak ditemukan.', data: [] };

  const invitedExamIds = findMany(
    'undangan',
    "StudentID = ? AND UPPER(COALESCE(Status,'')) != 'CANCELLED'",
    [student.StudentID]
  ).map((inv) => String(inv.ExamID));

  const myResults = new Map(
    findMany('nilai', 'StudentID = ?', [student.StudentID]).map((r) => [String(r.ExamID), r])
  );

  const exams = findMany('ujian', "UPPER(COALESCE(Status,'')) = 'PUBLISHED'", []).filter((exam) =>
    invitedExamIds.includes(String(exam.ExamID))
  );

  const result = exams.map((exam) => {
    const myResult = myResults.get(String(exam.ExamID)) || null;
    return {
      id: exam.ExamID,
      title: exam.NamaUjian,
      subject: exam.Mapel || '',
      duration: exam.DurasiMenit,
      date: exam.Tanggal || '',
      startTime: exam.JamMulai || '',
      endTime: exam.JamSelesai || '',
      status: exam.Status,
      completed: !!myResult,
      nilai: myResult ? myResult.Nilai : null
    };
  });

  return { ok: true, data: result };
}

/**
 * Setara getStudentQuestionsApi_(data) di Code.gs.
 */
function getStudentQuestionsApi(data) {
  const examId = String(data.examId || '').trim();
  const email = String(data.email || '').trim().toLowerCase();

  if (!examId) return { ok: false, message: 'ExamID wajib diisi.', data: [] };
  if (!email) return { ok: false, message: 'Email wajib diisi.', data: [] };

  const student = findStudentByEmail(email);
  if (!student) return { ok: false, message: 'Siswa tidak ditemukan.', data: [] };

  const exam = findExamById(examId);
  if (!exam) return { ok: false, message: 'Ujian tidak ditemukan.', data: [] };
  if (String(exam.Status || '').toUpperCase() !== 'PUBLISHED') {
    return { ok: false, message: 'Ujian belum tersedia.', data: [] };
  }

  const invitation = findInvitation(student.StudentID, examId);
  if (!invitation) {
    return { ok: false, message: 'Anda tidak memiliki undangan untuk ujian ini.', data: [] };
  }

  if (studentAlreadySubmitted(student.StudentID, examId)) {
    return {
      ok: false,
      message: 'Ujian ini sudah pernah Anda kerjakan dan dikumpulkan. Lihat nilainya di menu Hasil & Nilai.',
      data: []
    };
  }

  if (!isExamWithinWindow(exam, 0)) {
    return { ok: false, message: 'Ujian hanya dapat diakses pada jadwal yang ditentukan.', data: [] };
  }

  // Catat waktu mulai (hanya sekali).
  let startedAt;
  if (invitation.MulaiPada) {
    const existing = new Date(invitation.MulaiPada);
    startedAt = Number.isNaN(existing.getTime()) ? new Date() : existing;
  } else {
    startedAt = new Date();
    updateById('undangan', 'InviteID', invitation.InviteID, {
      MulaiPada: startedAt.toISOString(),
      Status: 'STARTED'
    });
  }

  const deadline = computePersonalDeadline(startedAt, exam);
  const remainingSeconds = Math.floor((deadline.getTime() - Date.now()) / 1000);

  if (remainingSeconds <= 0) {
    return { ok: false, message: 'Waktu pengerjaan Anda untuk ujian ini sudah habis.', data: [] };
  }

  const session = ensureExamSession(student, exam, invitation, deadline);
  const sessionStatusUpper = String(session.Status || '').toUpperCase();

  if (sessionStatusUpper === 'TERMINATED') {
    return {
      ok: false,
      message: 'Ujian Anda telah dihentikan oleh sistem/pengawas. Jawaban terakhir telah disimpan.',
      data: [],
      sessionId: session.SessionID,
      sessionStatus: sessionStatusUpper
    };
  }

  const rawQuestions = findMany('soal', 'ExamID = ?', [examId]);
  const questions = seededShuffle(rawQuestions, `${student.StudentID}:${examId}`).map((q) => ({
    id: q.QuestionID,
    question: q.Pertanyaan,
    optionA: q.PilihanA,
    optionB: q.PilihanB,
    optionC: q.PilihanC,
    optionD: q.PilihanD
    // SANGAT PENTING: JawabanBenar tidak dikirim ke client.
  }));

  return {
    ok: true,
    data: questions,
    remainingSeconds,
    deadline: deadline.toISOString(),
    sessionId: session.SessionID,
    sessionStatus: sessionStatusUpper,
    violationCount: safeNumber(session.ViolationCount, 0),
    antiCheat: examAntiCheatConfig(exam)
  };
}

/**
 * Setara submitStudentExamApi_(data) di Code.gs.
 *
 * Konkurensi: GAS memakai LockService.getScriptLock() (satu proses tulis
 * global untuk SELURUH aplikasi). Di sini transaksi SQLite
 * (BEGIN IMMEDIATE) hanya mengunci sesaat per operasi tulis dan tidak
 * saling blokir dengan siswa lain yang submit ujian BERBEDA/baris berbeda,
 * sehingga jauh lebih tahan untuk 500-700 siswa submit hampir bersamaan.
 */
function submitStudentExamApi(data) {
  const email = String(data.email || '').trim().toLowerCase();
  const examId = String(data.examId || '').trim();
  const answersRaw = data.answers;

  const student = findStudentByEmail(email);
  if (!student) return { ok: false, message: 'Siswa tidak ditemukan.' };
  if (!examId) return { ok: false, message: 'ExamID wajib diisi.' };

  const exam = findExamById(examId);
  if (!exam) return { ok: false, message: 'Ujian tidak ditemukan.' };
  if (String(exam.Status || '').toUpperCase() !== 'PUBLISHED') {
    return { ok: false, message: 'Ujian belum tersedia.' };
  }

  if (!isExamWithinWindow(exam, 120)) {
    return { ok: false, message: 'Waktu ujian sudah berakhir atau belum dimulai.' };
  }

  const invitation = findInvitation(student.StudentID, examId);
  if (!invitation) {
    return { ok: false, message: 'Anda tidak memiliki undangan untuk ujian ini.' };
  }

  const antiCheatSession = findActiveSessionFor(student.StudentID, examId);
  if (antiCheatSession) {
    const st = String(antiCheatSession.Status || '').toUpperCase();
    if (st === 'LOCKED') {
      return { ok: false, message: 'Ujian sedang terkunci. Masukkan PIN Pengawas untuk melanjutkan.' };
    }
    if (st === 'TERMINATED') {
      return { ok: false, message: 'Ujian ini telah dihentikan oleh sistem/pengawas.' };
    }
  }

  if (invitation.MulaiPada) {
    const startedAt = new Date(invitation.MulaiPada);
    if (!Number.isNaN(startedAt.getTime())) {
      const personalDeadline = computePersonalDeadline(startedAt, exam);
      const graceMs = 60 * 1000;
      if (Date.now() > personalDeadline.getTime() + graceMs) {
        return { ok: false, message: 'Waktu pengerjaan Anda untuk ujian ini sudah habis.' };
      }
    }
  }

  let answers = {};
  try {
    if (typeof answersRaw === 'string') {
      answers = JSON.parse(answersRaw || '{}');
    } else if (answersRaw && typeof answersRaw === 'object') {
      answers = answersRaw;
    }
  } catch (_err) {
    return { ok: false, message: 'Format jawaban tidak valid.' };
  }

  const questions = findMany('soal', 'ExamID = ?', [examId]);
  if (!questions.length) return { ok: false, message: 'Belum ada soal untuk ujian ini.' };

  let benar = 0;
  let salah = 0;
  let totalBobot = 0;
  let bobotBenar = 0;
  const answerNow = new Date().toISOString();
  const answerRows = [];

  questions.forEach((q) => {
    const questionId = String(q.QuestionID);
    const answer = String(answers[questionId] || '').trim().toUpperCase();
    const correct = String(q.JawabanBenar || '').trim().toUpperCase();
    const bobot = safeNumber(q.Bobot, 1) || 1;

    totalBobot += bobot;
    if (answer && answer === correct) {
      benar++;
      bobotBenar += bobot;
    } else {
      salah++;
    }

    answerRows.push({
      AnswerID: id('ANS'),
      ExamID: examId,
      StudentID: student.StudentID,
      QuestionID: questionId,
      Jawaban: answer,
      Waktu: answerNow
    });
  });

  const nilai = totalBobot > 0 ? Math.round((bobotBenar / totalBobot) * 10000) / 100 : 0;

  // Transaksi: cek ulang submit ganda + tulis Jawaban + Nilai + update
  // Undangan + tutup ExamSession, semuanya atomik (BEGIN IMMEDIATE...COMMIT).
  return withTransaction(() => {
    if (studentAlreadySubmitted(student.StudentID, examId)) {
      return { ok: false, message: 'Ujian ini sudah pernah dikumpulkan.' };
    }

    const insertAnswer = db.prepare(
      'INSERT INTO jawaban (AnswerID, ExamID, StudentID, QuestionID, Jawaban, Waktu) VALUES (?, ?, ?, ?, ?, ?)'
    );
    answerRows.forEach((a) => {
      insertAnswer.run(a.AnswerID, a.ExamID, a.StudentID, a.QuestionID, a.Jawaban, a.Waktu);
    });

    const resultObj = {
      ResultID: id('RES'),
      ExamID: examId,
      StudentID: student.StudentID,
      Benar: benar,
      Salah: salah,
      Nilai: nilai,
      Status: 'SELESAI',
      Waktu: new Date().toISOString()
    };
    insertRow('nilai', resultObj);

    const freshInvitation = findOne(
      'undangan',
      "ExamID = ? AND StudentID = ? AND UPPER(COALESCE(Status,'')) != 'CANCELLED'",
      [examId, student.StudentID]
    );
    if (freshInvitation) {
      updateById('undangan', 'InviteID', freshInvitation.InviteID, { Status: 'COMPLETED' });
    }

    const session = findActiveSessionFor(student.StudentID, examId);
    if (
      session &&
      !['SUBMITTED', 'FORCE_SUBMITTED', 'TERMINATED'].includes(String(session.Status || '').toUpperCase())
    ) {
      updateById('exam_sessions', 'SessionID', session.SessionID, {
        Status: 'SUBMITTED',
        ActualEndTime: new Date().toISOString()
      });
    }

    return {
      ok: true,
      message: 'Jawaban berhasil dikirim.',
      result: { id: resultObj.ResultID, benar, salah, nilai, status: resultObj.Status }
    };
  });
}

module.exports = {
  findStudentByEmail,
  findExamById,
  findInvitation,
  studentAlreadySubmitted,
  findActiveSessionFor,
  findSession,
  examAntiCheatConfig,
  getStudentExamsApi,
  getStudentQuestionsApi,
  submitStudentExamApi
};
