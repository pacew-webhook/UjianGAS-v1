const { findMany } = require('../repo/repo');
const { findStudentByEmail } = require('./exams');

function examMap() {
  const map = new Map();
  findMany('ujian', '1 = 1', []).forEach((e) => map.set(String(e.ExamID), e));
  return map;
}

/**
 * Setara getStudentInvitationsApi_(data) di Code.gs.
 */
function getStudentInvitationsApi(data) {
  const email = String(data.email || '').trim().toLowerCase();
  const student = findStudentByEmail(email);
  if (!student) return { ok: false, message: 'Siswa tidak ditemukan.', data: [] };

  const exams = examMap();
  const invitations = findMany(
    'undangan',
    "StudentID = ? AND UPPER(COALESCE(Status,'')) != 'CANCELLED'",
    [student.StudentID]
  );

  const result = invitations.map((inv) => {
    const exam = exams.get(String(inv.ExamID)) || {};
    return {
      id: inv.InviteID,
      examId: inv.ExamID,
      title: exam.NamaUjian || inv.ExamID,
      status: inv.Status,
      date: exam.Tanggal || '',
      startTime: exam.JamMulai || '',
      endTime: exam.JamSelesai || '',
      text: `${exam.NamaUjian || inv.ExamID} • ${exam.Tanggal || ''} ${exam.JamMulai || ''} • Status: ${inv.Status || ''}`
    };
  });

  return { ok: true, data: result };
}

/**
 * Setara getStudentResultsApi_(data) di Code.gs.
 */
function getStudentResultsApi(data) {
  const email = String(data.email || '').trim().toLowerCase();
  const student = findStudentByEmail(email);
  if (!student) return { ok: false, message: 'Siswa tidak ditemukan.', data: [] };

  const exams = examMap();
  const results = findMany('nilai', 'StudentID = ?', [student.StudentID]);

  const result = results.map((r) => {
    const exam = exams.get(String(r.ExamID)) || {};
    return {
      id: r.ResultID,
      examId: r.ExamID,
      title: exam.NamaUjian || r.ExamID,
      benar: r.Benar,
      salah: r.Salah,
      nilai: r.Nilai,
      status: r.Status,
      waktu: r.Waktu,
      text: `${exam.NamaUjian || r.ExamID} • Nilai: ${r.Nilai} • Benar: ${r.Benar} • Salah: ${r.Salah}`
    };
  });

  return { ok: true, data: result };
}

/**
 * Setara getStudentRemindersApi_(data) di Code.gs.
 * Target diasumsikan berisi 'ALL', ExamID, atau StudentID (sama seperti asal).
 */
function getStudentRemindersApi(data) {
  const email = String(data.email || '').trim().toLowerCase();
  const student = findStudentByEmail(email);
  if (!student) return { ok: false, message: 'Siswa tidak ditemukan.', data: [] };

  const exams = examMap();
  const myExamIds = new Set(
    findMany('undangan', "StudentID = ? AND UPPER(COALESCE(Status,'')) != 'CANCELLED'", [student.StudentID]).map(
      (inv) => String(inv.ExamID)
    )
  );

  const reminders = findMany('pengingat', '1 = 1', []).filter((r) => {
    const target = String(r.Target || '').toUpperCase();
    return target === 'ALL' || target === String(student.StudentID) || myExamIds.has(String(r.ExamID));
  });

  const result = reminders.map((r) => {
    const exam = exams.get(String(r.ExamID)) || {};
    return {
      id: r.ReminderID,
      examId: r.ExamID,
      title: exam.NamaUjian || r.ExamID || '',
      pesan: r.Pesan,
      waktu: r.Waktu
    };
  });

  return { ok: true, data: result };
}

module.exports = { getStudentInvitationsApi, getStudentResultsApi, getStudentRemindersApi };
