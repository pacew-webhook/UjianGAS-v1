const http = require('http');
const config = require('./config');
const { setupDatabase } = require('./src/db');
const { dispatch } = require('./src/routes');
const { readBody, sendJson } = require('./src/utils/http');

setupDatabase();

const server = http.createServer(async (req, res) => {
  // CORS longgar: dashboard Admin Guru & Android mengakses dari IP LAN
  // yang berbeda-beda, tidak ada asal (origin) tetap yang bisa dipatok.
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  if (req.method === 'GET' && req.url === '/') {
    sendJson(res, 200, { ok: true, message: 'UjianGAS local server aktif.' });
    return;
  }

  // Satu endpoint utama, setara Web App /exec di GAS: action dikirim di body.
  if (req.method === 'POST' && (req.url === '/exec' || req.url === '/')) {
    try {
      const data = await readBody(req);
      const result = dispatch(data || {});
      sendJson(res, 200, result);
    } catch (err) {
      sendJson(res, 400, { ok: false, message: err && err.message ? err.message : String(err) });
    }
    return;
  }

  sendJson(res, 404, { ok: false, message: 'Not found.' });
});

server.listen(config.PORT, config.HOST, () => {
  console.log(`UjianGAS local server berjalan di http://${config.HOST}:${config.PORT}`);
  console.log(`Dari device lain di jaringan yang sama, gunakan IP LAN laptop ini, contoh: http://192.168.1.10:${config.PORT}/exec`);
});
