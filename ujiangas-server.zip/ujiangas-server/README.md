# UjianGAS Local Server

Backend pengganti `admin-guru/Code.gs` (Google Apps Script + Google Sheets), berjalan **lokal di laptop** tanpa internet, sesuai `PRD_Migrasi_Backend_Lokal_UjianGAS.md`.

**Zero dependency** — hanya memakai modul bawaan Node.js (`http`, `node:sqlite`, `crypto`). Tidak perlu `npm install` sama sekali, penting untuk laptop guru yang mungkin tanpa internet.

## Syarat

- **Node.js versi 22.5 atau lebih baru** (modul `node:sqlite` masih eksperimental, tapi stabil untuk kebutuhan ini). Cek versi: `node --version`.

## Cara menjalankan

```bash
# 1. Buat admin awal (sekali saja)
node scripts/seed-admin.js "Nama Admin" admin@sekolah.sch.id passwordkuat

# 2. Jalankan server
node server.js
```

Server akan berjalan di `http://0.0.0.0:3000` — bisa diakses dari device lain di jaringan WiFi/LAN yang sama lewat IP laptop, contoh `http://192.168.1.10:3000/exec`. Cari IP laptop dengan `ipconfig` (Windows) atau `ifconfig`/`ip addr` (Mac/Linux).

Ubah port dengan variabel environment: `PORT=8080 node server.js`.

## Sambungkan ke Android

Di `GasApi.kt`, ganti base URL dari `.../exec` (Google Apps Script) menjadi:

```
http://<IP-LAN-LAPTOP>:3000/exec
```

Format request/response **sengaja dibuat identik** dengan `Code.gs` asli (form-urlencoded, field `action=...`, response `{ ok, data, message, ... }`) — tidak perlu mengubah logika parsing di Android, cukup ganti base URL.

## Migrasi data dari Google Sheets

1. Di Google Sheets: `File > Download > Comma-separated values (.csv)` untuk **setiap sheet**, simpan dengan nama sheet apa adanya: `Admin.csv`, `Siswa.csv`, `Ujian.csv`, `Soal.csv`, `Undangan.csv`, `Jawaban.csv`, `Nilai.csv`, `Pengingat.csv`, `ExamSessions.csv`, `Violations.csv`, `AuditLogs.csv`.
2. Taruh semua di satu folder, misal `./csv-export/`.
3. Jalankan:
   ```bash
   node scripts/migrate-from-csv.js ./csv-export
   ```
4. Sheets asli **tidak diubah/dihapus** — skrip ini hanya membaca.

Skrip aman dijalankan berulang: baris yang ID-nya sudah ada di database baru akan dilewati, tidak ditimpa.

## Verifikasi sebelum dipakai ujian sungguhan

```bash
# Uji fungsional end-to-end (login, soal, submit, anti-cheat, dst)
node scripts/smoke-test.js

# Uji beban: ganti 500 dengan jumlah siswa yang kamu targetkan
node scripts/load-test.js 500
```

Hasil pengujian di lingkungan development (bukan laptop guru yang sebenarnya — sebaiknya diulang di hardware asli):

| Jumlah siswa bersamaan | Hasil | Total waktu | Latensi submit (p95) |
|---|---|---|---|
| 500 | 500/500 berhasil | ~2.1 detik | 11 ms |
| 700 | 700/700 berhasil | ~3.1 detik | 11 ms |

Sebagai perbandingan, backend GAS+Sheets lama akan mulai gagal/timeout jauh di bawah angka ini (batas ~30 eksekusi simultan + `LockService` global).

## Endpoint yang sudah di-port (setara 1:1 dengan `Code.gs`)

**Android/siswa:** `login`, `register`, `exams`, `questions`, `submit`, `invitations`, `results`, `reminders`

**Anti-cheat & proctoring:** `violation`, `violation_batch`, `heartbeat`, `unlock`, `session_status`

Logika yang di-port persis dari `Code.gs`: hashing password bersalt (SHA-256 + salt, dengan fallback & migrasi diam-diam untuk akun lama), validasi jendela waktu ujian (termasuk ujian yang lewat tengah malam), pengacakan soal deterministik per siswa (`seededShuffle`, seed `StudentID:ExamID`), deadline personal per siswa (mulai + durasi, dibatasi jam selesai ujian), pencegahan buka-ulang ujian yang sudah dikumpulkan, rules engine pelanggaran (ACTIVE → WARNING → LOCKED/TERMINATED), dan verifikasi PIN Pengawas (hash+salt, bukan plaintext).

## Yang BELUM di-port (di luar scope draft ini)

Sesuai §3.1 PRD (dashboard Admin Guru), fase ini fokus ke API yang dipakai Android. Belum termasuk:

- Endpoint CRUD untuk dashboard Admin Guru (kelola ujian, kelola soal, kelola siswa, monitoring anti-cheat, unlock/force-submit oleh guru, audit log viewer). Ini murni pekerjaan tambahan (bukan migrasi ulang), karena pola generic table CRUD sudah tersedia di `src/repo/repo.js`.
- Sesi login admin (JWT/token) untuk dashboard tersebut.
- Import Bank Soal dari Excel (saat ini hanya lewat migrasi CSV data lama).

## Struktur project

```
server.js                  entry point HTTP
config.js                  port, path database, konstanta sesi
src/db.js                  schema SQLite (setara setupDatabase() di Code.gs)
src/routes.js              dispatcher action -> service (setara switch di doPost)
src/repo/repo.js           helper akses tabel generik + transaksi
src/services/auth.js       login, register
src/services/exams.js      exams, questions, submit
src/services/misc.js       invitations, results, reminders
src/services/anticheat.js  violation, violation_batch, heartbeat, unlock, session_status
src/utils/hash.js          hashing password bersalt (port dari hash_/hashPassword_ dll)
src/utils/shuffle.js       pengacakan soal deterministik (port dari seededShuffle_ dll)
src/utils/time.js          validasi jendela waktu ujian & deadline personal
scripts/seed-admin.js      buat admin awal
scripts/migrate-from-csv.js migrasi data dari Sheets (CSV)
scripts/smoke-test.js      uji fungsional end-to-end
scripts/load-test.js       uji beban concurrency
```

## Catatan produksi

- Database SQLite disimpan di `data/ujiangas.db` (dibuat otomatis, mode WAL untuk baca/tulis bersamaan). **Backup berkala** file ini (copy ke USB/drive lain) sebelum & selama hari ujian.
- Jalankan di laptop dengan baterai penuh/tercolok listrik + idealnya UPS — server ini adalah *single point of failure* untuk seluruh ujian.
- `node:sqlite` masih berstatus eksperimental di Node.js — untuk pemakaian jangka panjang/skala lebih besar, port ke PostgreSQL (lihat PRD §6) dapat dilakukan tanpa mengubah `src/services/*`, hanya `src/repo/repo.js` dan `src/db.js`.
