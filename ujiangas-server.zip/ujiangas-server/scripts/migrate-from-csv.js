/**
 * Migrasi data dari CSV hasil ekspor Google Sheets ke database baru,
 * sesuai PRD_Migrasi_Backend_Lokal_UjianGAS.md bagian 8.
 *
 * Cara pakai:
 *   1. Di Google Sheets: File > Download > tiap sheet sebagai .csv,
 *      simpan dengan nama PERSIS seperti nama sheet, contoh:
 *      Admin.csv, Siswa.csv, Ujian.csv, Soal.csv, Undangan.csv,
 *      Jawaban.csv, Nilai.csv, Pengingat.csv, ExamSessions.csv,
 *      Violations.csv, AuditLogs.csv
 *   2. Taruh semua file .csv itu dalam satu folder, misalnya ./csv-export/
 *   3. Jalankan: node scripts/migrate-from-csv.js ./csv-export
 *
 * Sheets lama TIDAK dihapus/diubah oleh skrip ini -- hanya dibaca.
 */
const fs = require('fs');
const path = require('path');
const { setupDatabase } = require('../src/db');
const { insertRow, findOne } = require('../src/repo/repo');

setupDatabase();

const folder = process.argv[2];
if (!folder) {
  console.error('Pemakaian: node scripts/migrate-from-csv.js <folder-csv-hasil-export-sheets>');
  process.exit(1);
}

// Peta nama sheet (nama file CSV) -> { table, idField, boolColumns }
// boolColumns: kolom yang di Sheets berupa teks 'ON'/'OFF' atau 'TRUE'/'FALSE',
// dikonversi ke 0/1 di database baru (lihat db.js).
const MAPPING = {
  Admin: { table: 'admin', idField: 'AdminID' },
  Siswa: { table: 'siswa', idField: 'StudentID' },
  Ujian: {
    table: 'ujian',
    idField: 'ExamID',
    boolColumns: [
      'AntiCheatOn',
      'ExamLockOn',
      'PreventScreenshot',
      'PreventScreenRecording',
      'PreventCopyPaste',
      'DetectBackground',
      'DetectSplitScreen',
      'RequireSupervisorPin'
    ]
  },
  Soal: { table: 'soal', idField: 'QuestionID' },
  Undangan: { table: 'undangan', idField: 'InviteID' },
  Jawaban: { table: 'jawaban', idField: 'AnswerID' },
  Nilai: { table: 'nilai', idField: 'ResultID' },
  Pengingat: { table: 'pengingat', idField: 'ReminderID' },
  ExamSessions: { table: 'exam_sessions', idField: 'SessionID' },
  Violations: { table: 'violations', idField: 'ViolationID' },
  AuditLogs: { table: 'audit_logs', idField: 'AuditID' }
};

/**
 * Parser CSV sederhana (mendukung field berkutip "..." dengan koma/newline
 * di dalamnya). Tidak pakai library eksternal supaya skrip ini tetap
 * berjalan tanpa koneksi internet / npm install.
 */
function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    const next = text[i + 1];

    if (inQuotes) {
      if (c === '"' && next === '"') {
        field += '"';
        i++;
      } else if (c === '"') {
        inQuotes = false;
      } else {
        field += c;
      }
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === ',') {
      row.push(field);
      field = '';
    } else if (c === '\n' || c === '\r') {
      if (c === '\r' && next === '\n') i++;
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else {
      field += c;
    }
  }
  if (field.length || row.length) {
    row.push(field);
    rows.push(row);
  }

  return rows.filter((r) => r.some((v) => v !== ''));
}

function toBoolInt(value) {
  const v = String(value || '').trim().toUpperCase();
  return ['ON', 'TRUE', '1', 'YES'].includes(v) ? 1 : 0;
}

function migrateFile(sheetName, filePath, mapping) {
  const raw = fs.readFileSync(filePath, 'utf8');
  const rows = parseCsv(raw);
  if (rows.length < 2) {
    console.log(`  ${sheetName}: kosong, dilewati.`);
    return { inserted: 0, skipped: 0 };
  }

  const headers = rows[0].map((h) => h.trim());
  let inserted = 0;
  let skipped = 0;

  for (let r = 1; r < rows.length; r++) {
    const values = rows[r];
    const obj = {};
    headers.forEach((h, i) => {
      let v = values[i] !== undefined ? values[i] : '';
      if (mapping.boolColumns && mapping.boolColumns.includes(h)) {
        v = toBoolInt(v);
      }
      obj[h] = v === '' ? null : v;
    });

    const idValue = obj[mapping.idField];
    if (!idValue) {
      skipped++;
      continue;
    }

    const existing = findOne(mapping.table, `${mapping.idField} = ?`, [idValue]);
    if (existing) {
      skipped++; // Sudah ada (migrasi dijalankan berulang) -> lewati, tidak menimpa.
      continue;
    }

    try {
      insertRow(mapping.table, obj);
      inserted++;
    } catch (err) {
      console.error(`  Gagal insert baris ${mapping.idField}=${idValue}: ${err.message}`);
      skipped++;
    }
  }

  return { inserted, skipped };
}

console.log(`Membaca CSV dari: ${folder}\n`);

Object.keys(MAPPING).forEach((sheetName) => {
  const filePath = path.join(folder, `${sheetName}.csv`);
  if (!fs.existsSync(filePath)) {
    console.log(`- ${sheetName}.csv tidak ditemukan, dilewati.`);
    return;
  }

  const { inserted, skipped } = migrateFile(sheetName, filePath, MAPPING[sheetName]);
  console.log(`- ${sheetName}: ${inserted} baris dimigrasikan, ${skipped} dilewati (kosong/sudah ada).`);
});

console.log('\nSelesai. Data Google Sheets asli tidak diubah/dihapus.');
