/**
 * Uji beban sederhana: N siswa berbeda, tiap siswa login -> ambil soal ->
 * submit, semuanya ditembak SECARA BERSAMAAN (Promise.all) lewat HTTP asli
 * ke server yang berjalan di proses ini. Tujuannya membuktikan tidak ada
 * error terkait lock/quota seperti yang terjadi di backend GAS+Sheets lama.
 *
 * Jalankan: node scripts/load-test.js [jumlahSiswa]
 */
process.env.DB_PATH = require('path').join(__dirname, '..', 'data', 'load-test.db');
const fs = require('fs');
[process.env.DB_PATH, process.env.DB_PATH + '-wal', process.env.DB_PATH + '-shm'].forEach((f) => {
  if (fs.existsSync(f)) fs.unlinkSync(f);
});

const http = require('http');
const { setupDatabase } = require('../src/db');
const { insertRow } = require('../src/repo/repo');
const { generateSalt, hashPassword, id } = require('../src/utils/hash');
const { dispatch } = require('../src/routes');
const { readBody, sendJson } = require('../src/utils/http');

setupDatabase();

const N = Number(process.argv[2] || 500);

const now = new Date();
const pad = (n) => String(n).padStart(2, '0');
const tanggal = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
const jamMulai = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
const jamSelesaiDate = new Date(now.getTime() + 3 * 60 * 60 * 1000);
const jamSelesai = `${pad(jamSelesaiDate.getHours())}:${pad(jamSelesaiDate.getMinutes())}`;

const exam = {
  ExamID: id('EXM'),
  NamaUjian: 'Load Test Exam',
  Mapel: 'Umum',
  DurasiMenit: 120,
  Tanggal: tanggal,
  JamMulai: jamMulai,
  JamSelesai: jamSelesai,
  Status: 'PUBLISHED',
  CreatedAt: new Date().toISOString(),
  CreatedBy: 'ADM-TEST',
  AntiCheatOn: 0,
  ExamLockOn: 0,
  PreventScreenshot: 0,
  PreventScreenRecording: 0,
  PreventCopyPaste: 0,
  DetectBackground: 0,
  DetectSplitScreen: 0,
  MaxViolations: 3,
  ActionAfterLimit: 'LOCK',
  RequireSupervisorPin: 0,
  SupervisorPinHash: null,
  SupervisorPinSalt: null
};
insertRow('ujian', exam);

const questionIds = [];
for (let i = 0; i < 20; i++) {
  const q = {
    QuestionID: id('Q'),
    ExamID: exam.ExamID,
    Pertanyaan: `Soal nomor ${i + 1}`,
    PilihanA: 'A',
    PilihanB: 'B',
    PilihanC: 'C',
    PilihanD: 'D',
    JawabanBenar: 'A',
    Bobot: 1,
    CreatedAt: new Date().toISOString()
  };
  insertRow('soal', q);
  questionIds.push(q.QuestionID);
}

console.log(`Menyiapkan ${N} siswa + undangan...`);
const students = [];
for (let i = 0; i < N; i++) {
  const salt = generateSalt();
  const student = {
    StudentID: id('STU'),
    Nama: `Siswa ${i}`,
    Email: `siswa${i}@loadtest.local`,
    PasswordHash: hashPassword('pass', salt),
    Salt: salt,
    Kelas: '12-LOAD',
    Status: 'ACTIVE',
    CreatedAt: new Date().toISOString()
  };
  insertRow('siswa', student);
  insertRow('undangan', {
    InviteID: id('INV'),
    ExamID: exam.ExamID,
    StudentID: student.StudentID,
    Status: 'PENDING',
    SentAt: new Date().toISOString(),
    MulaiPada: null
  });
  students.push(student);
}

const server = http.createServer(async (req, res) => {
  const data = await readBody(req);
  const result = dispatch(data || {});
  sendJson(res, 200, result);
});

function post(port, body) {
  return new Promise((resolve, reject) => {
    const payload = new URLSearchParams(body).toString();
    const req = http.request(
      {
        host: '127.0.0.1',
        port,
        path: '/exec',
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(payload) }
      },
      (res) => {
        let raw = '';
        res.on('data', (c) => (raw += c));
        res.on('end', () => {
          try {
            resolve({ status: res.statusCode, body: JSON.parse(raw) });
          } catch (err) {
            reject(err);
          }
        });
      }
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

async function studentFlow(port, student) {
  const t0 = Date.now();
  const q = await post(port, { action: 'questions', examId: exam.ExamID, email: student.Email });
  const tQuestions = Date.now() - t0;
  if (!q.body.ok) return { ok: false, stage: 'questions', message: q.body.message };

  const answers = {};
  q.body.data.forEach((qq) => (answers[qq.id] = 'A'));

  const t1 = Date.now();
  const s = await post(port, { action: 'submit', email: student.Email, examId: exam.ExamID, answers: JSON.stringify(answers) });
  const tSubmit = Date.now() - t1;
  if (!s.body.ok) return { ok: false, stage: 'submit', message: s.body.message };

  return { ok: true, tQuestions, tSubmit, nilai: s.body.result.nilai };
}

server.listen(0, '127.0.0.1', async () => {
  const port = server.address().port;
  console.log(`Server siap di port ${port}. Menembak ${N} siswa BERSAMAAN (questions -> submit)...\n`);

  const wallStart = Date.now();
  const results = await Promise.all(students.map((s) => studentFlow(port, s)));
  const wallMs = Date.now() - wallStart;

  const ok = results.filter((r) => r.ok);
  const failed = results.filter((r) => !r.ok);

  const qTimes = ok.map((r) => r.tQuestions).sort((a, b) => a - b);
  const sTimes = ok.map((r) => r.tSubmit).sort((a, b) => a - b);
  const p = (arr, pct) => (arr.length ? arr[Math.min(arr.length - 1, Math.floor((arr.length - 1) * pct))] : 0);

  console.log(`Total waktu wall-clock untuk ${N} siswa bersamaan: ${wallMs} ms`);
  console.log(`Berhasil: ${ok.length}/${N}, Gagal: ${failed.length}/${N}`);
  if (qTimes.length) {
    console.log(`Latensi 'questions' (ms) - p50: ${p(qTimes, 0.5)}, p95: ${p(qTimes, 0.95)}, max: ${qTimes[qTimes.length - 1]}`);
    console.log(`Latensi 'submit'    (ms) - p50: ${p(sTimes, 0.5)}, p95: ${p(sTimes, 0.95)}, max: ${sTimes[sTimes.length - 1]}`);
  }
  if (failed.length) {
    console.log('\nContoh kegagalan (maks 5):');
    failed.slice(0, 5).forEach((f) => console.log(' -', f.stage, ':', f.message));
  }

  server.close();
  process.exitCode = failed.length ? 1 : 0;
});
