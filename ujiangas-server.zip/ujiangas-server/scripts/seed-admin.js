/**
 * Setara createInitialAdmin() di Code.gs.
 * Jalankan sekali: node scripts/seed-admin.js "Nama Admin" admin@sekolah.sch.id passwordkuat
 */
const { setupDatabase } = require('../src/db');
const { findOne, insertRow } = require('../src/repo/repo');
const { generateSalt, hashPassword, id } = require('../src/utils/hash');

setupDatabase();

const [, , nama, email, password] = process.argv;

if (!nama || !email || !password) {
  console.error('Pemakaian: node scripts/seed-admin.js "Nama Admin" admin@sekolah.sch.id passwordkuat');
  process.exit(1);
}

const emailLower = String(email).trim().toLowerCase();
const existing = findOne('admin', 'LOWER(Email) = ?', [emailLower]);

if (existing) {
  console.error(`Admin dengan email ${emailLower} sudah ada (AdminID: ${existing.AdminID}). Tidak ada perubahan.`);
  process.exit(1);
}

const salt = generateSalt();
const admin = {
  AdminID: id('ADM'),
  Nama: nama,
  Email: emailLower,
  PasswordHash: hashPassword(password, salt),
  Salt: salt,
  Role: 'SUPERADMIN',
  Status: 'ACTIVE',
  CreatedAt: new Date().toISOString()
};

insertRow('admin', admin);
console.log(`Admin awal berhasil dibuat: ${admin.Email} (AdminID: ${admin.AdminID})`);
console.log('Segera ganti/nonaktifkan kredensial contoh setelah ini jika dipakai untuk produksi.');
