/**
 * Smoke test end-to-end (bukan bagian dari deliverable produksi, murni
 * untuk verifikasi selama development). Menjalankan server in-process,
 * menyiapkan data contoh langsung ke DB, lalu memukul tiap endpoint API
 * lewat HTTP asli (bukan memanggil fungsi service langsung) supaya jalur
 * HTTP + parsing body ikut teruji.
 */
process.env.DB_PATH = require('path').join(__dirname, '..', 'data', 'smoke-test.db');
const fs = require('fs');
if (fs.existsSync(process.env.DB_PATH)) fs.unlinkSync(process.env.DB_PATH);
for (const ext of ['-wal', '-shm']) {
  if (fs.existsSync(process.env.DB_PATH + ext)) fs.unlinkSync(process.env.DB_PATH + ext);
}

const http = require('http');
const config = require('../config');
const { setupDatabase } = require('../src/db');
const { insertRow } = require('../src/repo/repo');
const { generateSalt, hashPassword, id } = require('../src/utils/hash');
const { dispatch } = require('../src/routes');
const { readBody, sendJson } = require('../src/utils/http');

setupDatabase();

// ---- Data contoh ----
const salt = generateSalt();
const student = {
  StudentID: id('STU'),
  Nama: 'Budi Santoso',
  Email: 'budi@sekolah.sch.id',
  PasswordHash: hashPassword('rahasia123', salt),
  Salt: salt,
  Kelas: '12 IPA 1',
  Status: 'ACTIVE',
  CreatedAt: new Date().toISOString()
};
insertRow('siswa', student);

const now = new Date();
const pad = (n) => String(n).padStart(2, '0');
const tanggal = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
const jamMulai = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
const jamSelesaiDate = new Date(now.getTime() + 2 * 60 * 60 * 1000);
const jamSelesai = `${pad(jamSelesaiDate.getHours())}:${pad(jamSelesaiDate.getMinutes())}`;

const pinSalt = generateSalt();
const exam = {
  ExamID: id('EXM'),
  NamaUjian: 'Ujian Matematika Bab 1',
  Mapel: 'Matematika',
  DurasiMenit: 60,
  Tanggal: tanggal,
  JamMulai: jamMulai,
  JamSelesai: jamSelesai,
  Status: 'PUBLISHED',
  CreatedAt: new Date().toISOString(),
  CreatedBy: 'ADM-TEST',
  AntiCheatOn: 1,
  ExamLockOn: 1,
  PreventScreenshot: 1,
  PreventScreenRecording: 1,
  PreventCopyPaste: 1,
  DetectBackground: 1,
  DetectSplitScreen: 1,
  MaxViolations: 3,
  ActionAfterLimit: 'LOCK',
  RequireSupervisorPin: 1,
  SupervisorPinHash: hashPassword('123456', pinSalt),
  SupervisorPinSalt: pinSalt
};
insertRow('ujian', exam);

const questions = [
  { QuestionID: id('Q'), ExamID: exam.ExamID, Pertanyaan: '1+1=?', PilihanA: '1', PilihanB: '2', PilihanC: '3', PilihanD: '4', JawabanBenar: 'B', Bobot: 1, CreatedAt: new Date().toISOString() },
  { QuestionID: id('Q'), ExamID: exam.ExamID, Pertanyaan: '2+2=?', PilihanA: '3', PilihanB: '4', PilihanC: '5', PilihanD: '6', JawabanBenar: 'B', Bobot: 1, CreatedAt: new Date().toISOString() },
  { QuestionID: id('Q'), ExamID: exam.ExamID, Pertanyaan: '3+3=?', PilihanA: '5', PilihanB: '6', PilihanC: '7', PilihanD: '8', JawabanBenar: 'B', Bobot: 1, CreatedAt: new Date().toISOString() }
];
questions.forEach((q) => insertRow('soal', q));

const invitation = {
  InviteID: id('INV'),
  ExamID: exam.ExamID,
  StudentID: student.StudentID,
  Status: 'PENDING',
  SentAt: new Date().toISOString(),
  MulaiPada: null
};
insertRow('undangan', invitation);

// ---- Server in-process ----
const server = http.createServer(async (req, res) => {
  const data = await readBody(req);
  const result = dispatch(data || {});
  sendJson(res, 200, result);
});

function post(port, body) {
  return new Promise((resolve, reject) => {
    const payload = new URLSearchParams(body).toString();
    const req = http.request(
      { host: '127.0.0.1', port, path: '/exec', method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        let raw = '';
        res.on('data', (c) => (raw += c));
        res.on('end', () => {
          try {
            resolve(JSON.parse(raw));
          } catch (err) {
            reject(err);
          }
        });
      }
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

let failures = 0;
function check(label, cond, extra) {
  if (cond) {
    console.log(`OK   - ${label}`);
  } else {
    failures++;
    console.log(`FAIL - ${label}`, extra !== undefined ? JSON.stringify(extra) : '');
  }
}

server.listen(0, '127.0.0.1', async () => {
  const port = server.address().port;
  try {
    // 1. Login gagal (password salah)
    const badLogin = await post(port, { action: 'login', email: student.Email, password: 'salah' });
    check('login gagal untuk password salah', badLogin.ok === false, badLogin);

    // 2. Login sukses
    const login = await post(port, { action: 'login', email: student.Email, password: 'rahasia123' });
    check('login sukses', login.ok === true && login.data.studentId === student.StudentID, login);

    // 3. Register siswa baru
    const reg = await post(port, { action: 'register', nama: 'Siti Aminah', email: 'siti@sekolah.sch.id', password: 'pass123', kelas: '12 IPA 2' });
    check('register siswa baru sukses', reg.ok === true, reg);

    const regDup = await post(port, { action: 'register', nama: 'Siti Aminah', email: 'siti@sekolah.sch.id', password: 'pass123', kelas: '12 IPA 2' });
    check('register email duplikat ditolak', regDup.ok === false, regDup);

    // 4. Daftar ujian siswa (harus muncul karena sudah diundang & PUBLISHED)
    const exams = await post(port, { action: 'exams', email: student.Email });
    check('daftar ujian siswa berisi 1 ujian', exams.ok === true && exams.data.length === 1 && exams.data[0].completed === false, exams);

    // 5. Ambil soal (harus teracak tapi lengkap 3 soal, tanpa JawabanBenar)
    const questionsResp = await post(port, { action: 'questions', examId: exam.ExamID, email: student.Email });
    check(
      'ambil soal: 3 soal, ada sessionId, tidak bocorkan JawabanBenar',
      questionsResp.ok === true &&
        questionsResp.data.length === 3 &&
        !!questionsResp.sessionId &&
        questionsResp.data.every((q) => q.JawabanBenar === undefined),
      questionsResp
    );
    const sessionId = questionsResp.sessionId;

    // 6. Ambil soal lagi -> sessionId harus SAMA (bukan sesi baru) & urutan soal identik (deterministik)
    const questionsResp2 = await post(port, { action: 'questions', examId: exam.ExamID, email: student.Email });
    check('ambil soal ulang: sessionId sama (tidak reset)', questionsResp2.sessionId === sessionId, questionsResp2);
    check(
      'urutan soal konsisten antar pemuatan (seeded shuffle deterministik)',
      JSON.stringify(questionsResp.data.map((q) => q.id)) === JSON.stringify(questionsResp2.data.map((q) => q.id))
    );

    // 7. Heartbeat
    const hb = await post(port, { action: 'heartbeat', email: student.Email, examId: exam.ExamID, sessionId, remainingSeconds: 3000, appState: 'FOREGROUND' });
    check('heartbeat sukses', hb.ok === true && hb.status === 'ACTIVE', hb);

    // 8. Lapor pelanggaran 1x -> status jadi WARNING (max 3)
    const v1 = await post(port, { action: 'violation', email: student.Email, examId: exam.ExamID, sessionId, type: 'APP_BACKGROUND', severity: 'WARNING', description: 'Keluar aplikasi sebentar' });
    check('violation #1 -> status WARNING', v1.ok === true && v1.violationCount === 1 && v1.status === 'WARNING', v1);

    // 9. Lapor pelanggaran ke-2 dan ke-3 -> status jadi LOCKED (>= maxViolations)
    await post(port, { action: 'violation', email: student.Email, examId: exam.ExamID, sessionId, type: 'SPLIT_SCREEN', severity: 'WARNING', description: 'Split screen' });
    const v3 = await post(port, { action: 'violation', email: student.Email, examId: exam.ExamID, sessionId, type: 'SCREENSHOT', severity: 'CRITICAL', description: 'Screenshot terdeteksi' });
    check('violation #3 -> status LOCKED', v3.ok === true && v3.violationCount === 3 && v3.status === 'LOCKED', v3);

    // 10. Submit ditolak karena sesi LOCKED
    const submitLocked = await post(port, { action: 'submit', email: student.Email, examId: exam.ExamID, answers: JSON.stringify({ [questions[0].QuestionID]: 'B', [questions[1].QuestionID]: 'B', [questions[2].QuestionID]: 'A' }) });
    check('submit ditolak saat sesi LOCKED', submitLocked.ok === false, submitLocked);

    // 11. Unlock dengan PIN salah -> gagal
    const unlockWrong = await post(port, { action: 'unlock', email: student.Email, examId: exam.ExamID, sessionId, pin: '000000' });
    check('unlock PIN salah ditolak', unlockWrong.ok === false, unlockWrong);

    // 12. Unlock dengan PIN benar -> sukses, status ACTIVE lagi
    const unlockOk = await post(port, { action: 'unlock', email: student.Email, examId: exam.ExamID, sessionId, pin: '123456' });
    check('unlock PIN benar -> status ACTIVE', unlockOk.ok === true && unlockOk.status === 'ACTIVE', unlockOk);

    // 13. Submit sekarang berhasil: 2 benar, 1 salah -> nilai 66.67
    const submitOk = await post(port, { action: 'submit', email: student.Email, examId: exam.ExamID, answers: JSON.stringify({ [questions[0].QuestionID]: 'B', [questions[1].QuestionID]: 'B', [questions[2].QuestionID]: 'A' }) });
    check('submit sukses: 2 benar, 1 salah', submitOk.ok === true && submitOk.result.benar === 2 && submitOk.result.salah === 1, submitOk);

    // 14. Submit kedua kalinya harus ditolak (cegah submit ganda)
    const submitTwice = await post(port, { action: 'submit', email: student.Email, examId: exam.ExamID, answers: '{}' });
    check('submit ganda ditolak', submitTwice.ok === false, submitTwice);

    // 15. Ambil soal lagi setelah submit -> ditolak (sudah dikumpulkan)
    const questionsAfterSubmit = await post(port, { action: 'questions', examId: exam.ExamID, email: student.Email });
    check('ambil soal setelah submit ditolak', questionsAfterSubmit.ok === false, questionsAfterSubmit);

    // 16. Daftar ujian sekarang menunjukkan completed=true & nilai terisi
    const examsAfter = await post(port, { action: 'exams', email: student.Email });
    check('daftar ujian: completed true & nilai ~66.67', examsAfter.data[0].completed === true && Math.abs(examsAfter.data[0].nilai - 66.67) < 0.01, examsAfter);

    // 17. Hasil & Nilai
    const results = await post(port, { action: 'results', email: student.Email });
    check('endpoint results mengembalikan 1 hasil', results.ok === true && results.data.length === 1, results);

    // 18. session_status
    const statusResp = await post(port, { action: 'session_status', sessionId });
    check('session_status: SUBMITTED', statusResp.ok === true && statusResp.status === 'SUBMITTED', statusResp);

    // 19. Action tidak dikenal
    const unknown = await post(port, { action: 'tidak_ada_begini' });
    check('action tidak dikenal ditangani rapi', unknown.ok === false, unknown);

    console.log(`\n${failures === 0 ? 'SEMUA TEST LULUS' : failures + ' TEST GAGAL'}`);
    process.exitCode = failures === 0 ? 0 : 1;
  } catch (err) {
    console.error('Smoke test error:', err);
    process.exitCode = 1;
  } finally {
    server.close();
  }
});
