const path = require('path');

module.exports = {
  PORT: Number(process.env.PORT || 3000),
  // '0.0.0.0' supaya bisa diakses device lain di jaringan lokal (WiFi/LAN),
  // bukan cuma dari laptop server itu sendiri (127.0.0.1).
  HOST: process.env.HOST || '0.0.0.0',
  DB_PATH: process.env.DB_PATH || path.join(__dirname, 'data', 'ujiangas.db'),
  // Sesi admin dashboard, setara SESSION_SECONDS di Code.gs (6 jam).
  SESSION_SECONDS: 21600,
  // Toleransi jaringan saat submit mendekati/lewat batas waktu ujian,
  // setara toleransi 120 detik yang disebut di README project asal.
  SUBMIT_GRACE_SECONDS: 120
};
